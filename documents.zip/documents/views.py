from django.shortcuts import render
from rest_framework import status, mixins, viewsets, authentication, permissions,filters
from rest_framework_jwt.authentication import JSONWebTokenAuthentication
from rest_framework.permissions import IsAuthenticated
from .serializers import *
from .models import Document
from django.http.response import JsonResponse
import datetime
#from.filters import DocsFilter
from django_filters.rest_framework import  DjangoFilterBackend
from projects.models import *
from team.models import Team
from rest_framework.response import Response
import json
# Create your views here.
#编辑文档
class DocEditViewset(mixins.RetrieveModelMixin,mixins.ListModelMixin, mixins.CreateModelMixin, mixins.DestroyModelMixin,
                         mixins.UpdateModelMixin, viewsets.GenericViewSet):
    """"
    create:
    创建文档
    destroy:
    删除文档
    update:
    修改文档
    retrieve:
    查看文档
    """
    queryset = Document.objects.all()
    serializer_class = DocCreateSerializer
    permission_classes = (IsAuthenticated, )
    authentication_classes = (JSONWebTokenAuthentication, authentication.SessionAuthentication)
    #创建文档权限：团队创建者，可写协作者
    def create(self, request, *args, **kwargs):
        # 如果是团队空间 登录即可创建。
        if request.data['type'] =='1':       #必须加引号！！！！！
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        #如果是文档
        elif request.data['type'] == '0':
            if request.data['parent_doc'] == '': #parent _doc 空创建单个文件
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                self.perform_create(serializer)
                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
            else:  #在某团队空间（parent_doc）下创建文件
                project = request.data['parent_doc']
                #团队空间是私密的 文件必须是私密的
                parent =Document.objects.get(id=project)
                if parent.role == 1:
                    if request.data['role']== '1':
                        pass
                    elif request.data['role'] == '':
                        request.data._mutable = True
                        request.data['role'] = '1'
                    else : #文件不能是公开的
                        return Response(status=status.HTTP_204_NO_CONTENT)
                else: #团队公开 可以指定
                    pass
                # 请求的用户是团队的创建者
                check_project = Document.objects.filter(id=project, create_user=request.user)
                # 请求用户是团队的可写协作者
                colla_project = Team.objects.filter(document_id=project, user=request.user, role=0)
                # 请求创建文档
                if check_project.count() > 0 or colla_project.count() > 0:
                    serializer = self.get_serializer(data=request.data)
                    serializer.is_valid(raise_exception=True)
                    self.perform_create(serializer)
                    headers = self.get_success_headers(serializer.data)
                    return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
                else: #请求失败
                    return Response(status=status.HTTP_404_NOT_FOUND)

        else:
            return Response(status=status.HTTP_401_UNAUTHORIZED)

    def perform_create(self, serializer):
        instance=serializer.save()
        project=instance.parent_doc #父文档
        # 新建文档继承父空间的协作关系
        parentteams= Team.objects.filter(document_id=project)#父空间的协作关系集合
        #inheritors =parentteam.values_list('user', flat=True)
        for parentteam in parentteams:
            Team.objects.create(document=instance, user=parentteam.user,role=parentteam.role)


    def get_serializer_class(self):
        if self.action=='create':
            return DocCreateSerializer
        return DocCreateSerializer
